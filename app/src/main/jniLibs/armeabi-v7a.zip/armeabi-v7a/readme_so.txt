libjiagu_sdk_cxsdkProtected.so  SdkGlobal.setContext(this)	初始化需要

libImageOverlay.so  GlobalHelper.getInstance(applicationContext)	初始化需要

libDes.so   	登陆需要

libavutil-54.so 		mRenderView.rend(inputVideo)  播放时需要
libswresample-1.so 		mRenderView.rend(inputVideo)  播放时需要
libavcodec-56.so 		mRenderView.rend(inputVideo)  播放时需要
libavformat-56.so 		mRenderView.rend(inputVideo)  播放时需要
libswscale-3.so  		mRenderView.rend(inputVideo)  播放时需要
libpostproc-53.so 		mRenderView.rend(inputVideo)  播放时需要
libavfilter-5.so 		mRenderView.rend(inputVideo)  播放时需要
libavdevice-56.so 		mRenderView.rend(inputVideo)  播放时需要
libHW_H265dec_Andr.so 	mRenderView.rend(inputVideo)  播放时需要
libCS_H264dec.so 		mRenderView.rend(inputVideo)  播放时需要
libVideoDecoder.so 		mRenderView.rend(inputVideo)  播放时需要

libAudioEncoder 		client!!.handleCall() 	对讲需要
libCrWebRtcAec.so 		client!!.handleCall() 	对讲需要
libwebrtc_aecm.so 		client!!.handleCall() 	对讲需要

libAudioDecoder.so 		client!!.handlePlay()	扩音需要
libAacFFmpegDecoder.so 	client!!.handlePlay()	扩音需要